
# Stock Price Prediction using Linear Regression

This project predicts the next day's stock price using Linear Regression based on historical closing prices.

## 📂 Files Included
- `stock_prices.csv`: Sample dataset with stock prices over 10 days.
- `predict_stock_price.py`: Python script that reads data, trains a Linear Regression model, and visualizes predictions.
- `README.md`: Project explanation.

## 🚀 How to Run
1. Install required libraries:
```
pip install pandas scikit-learn matplotlib
```
2. Run the Python script:
```
python predict_stock_price.py
```

## 📊 Example Output
- Console output of predicted prices.
- Graph showing actual vs predicted prices.

---
Simple, beginner-friendly project for practicing Machine Learning with stock data.
