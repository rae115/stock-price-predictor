
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Step 1: Load Data
df = pd.read_csv('stock_prices.csv')
X = df[['Day']]
y = df['Price']

# Step 2: Train Linear Regression Model
model = LinearRegression()
model.fit(X, y)

# Step 3: Predict for next day
next_day = [[11]]
predicted_price = model.predict(next_day)
print(f"Predicted stock price for Day 11: ₹{predicted_price[0]:.2f}")

# Step 4: Plot
plt.scatter(X, y, color='blue', label='Actual Prices')
plt.plot(X, model.predict(X), color='red', label='Prediction Line')
plt.scatter(next_day, predicted_price, color='green', label='Prediction for Day 11')
plt.xlabel('Day')
plt.ylabel('Price')
plt.title('Stock Price Prediction using Linear Regression')
plt.legend()
plt.show()
